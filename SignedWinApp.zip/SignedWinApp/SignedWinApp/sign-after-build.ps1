# sign-after-build.ps1
# Called automatically by the MSBuild AuthenticodeSign target.
# Finds signtool and Authenticode-signs the built EXE.

param(
    [Parameter(Mandatory = $true)]
    [string]$TargetPath,

    [Parameter(Mandatory = $true)]
    [string]$PfxPath,

    [string]$Password = "SamplePassword123!"
)

$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Authenticode Signing (automatic)" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

if ([string]::IsNullOrWhiteSpace($TargetPath) -or -not (Test-Path -LiteralPath $TargetPath)) {
    Write-Host "ERROR: Target not found or empty: '$TargetPath'" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path -LiteralPath $PfxPath)) {
    Write-Host "WARNING: PFX not found: $PfxPath" -ForegroundColor Yellow
    Write-Host "         Skipping Authenticode signing." -ForegroundColor Yellow
    exit 0
}

# --------------------------------------------------
# Locate signtool.exe (any installed Windows SDK)
# --------------------------------------------------
$signtool = $null

$searchRoots = @(
    "${env:ProgramFiles(x86)}\Windows Kits\10\bin",
    "${env:ProgramFiles}\Windows Kits\10\bin",
    "${env:ProgramFiles(x86)}\Windows Kits\8.1\bin",
    "${env:ProgramFiles(x86)}\Microsoft SDKs\Windows"
)

foreach ($root in $searchRoots) {
    if (-not (Test-Path $root)) { continue }

    $candidates = Get-ChildItem -Path $root -Recurse -Filter "signtool.exe" -ErrorAction SilentlyContinue |
                  Where-Object { $_.FullName -match '\\x64\\' -or $_.FullName -match '\\x86\\' }

    if ($candidates) {
        $signtool = ($candidates | Sort-Object FullName -Descending | Select-Object -First 1).FullName
        break
    }
}

# Also check PATH
if (-not $signtool) {
    $cmd = Get-Command "signtool.exe" -ErrorAction SilentlyContinue
    if ($cmd) { $signtool = $cmd.Source }
}

if (-not $signtool) {
    Write-Host "WARNING: signtool.exe not found." -ForegroundColor Yellow
    Write-Host "         Install the Windows 10/11 SDK (Visual Studio Installer)." -ForegroundColor Yellow
    Write-Host "         Strong-name signing is still applied." -ForegroundColor Yellow
    exit 0
}

Write-Host "signtool : $signtool"
Write-Host "Target   : $TargetPath"
Write-Host "PFX      : $PfxPath"
Write-Host ""

# --------------------------------------------------
# Sign
# --------------------------------------------------
& $signtool sign `
    /f $PfxPath `
    /p $Password `
    /tr "http://timestamp.digicert.com" `
    /td sha256 `
    /fd sha256 `
    /d "SignedWinApp - Sample Signed Application" `
    $TargetPath

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Signing failed (exit code $LASTEXITCODE)" -ForegroundColor Red
    exit $LASTEXITCODE
}

Write-Host ""
Write-Host "Successfully signed." -ForegroundColor Green

# Verify (non-fatal)
& $signtool verify /pa $TargetPath 2>$null
if ($LASTEXITCODE -eq 0) {
    Write-Host "Signature verified OK." -ForegroundColor Green
}

Write-Host "========================================" -ForegroundColor Cyan
exit 0
