using System;
using System.Windows.Forms;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;

namespace SignedWinApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Display signing information at startup (optional diagnostic)
            ShowSigningInfo();

            Application.Run(new MainForm());
        }

        private static void ShowSigningInfo()
        {
            try
            {
                var assembly = Assembly.GetExecutingAssembly();
                var location = assembly.Location;

                // Check strong-name signature
                bool isStrongNamed = false;
                try
                {
                    // This will throw if not strong-named
                    var name = assembly.GetName();
                    isStrongNamed = name.GetPublicKey() != null && name.GetPublicKey().Length > 0;
                }
                catch { }

                // Check Authenticode signature
                string authenticodeStatus = "Not signed / Not verified";
                try
                {
                    var cert = X509Certificate.CreateFromSignedFile(location);
                    if (cert != null)
                    {
                        authenticodeStatus = $"Signed by: {cert.Subject}";
                    }
                }
                catch
                {
                    authenticodeStatus = "No Authenticode signature found";
                }

                MessageBox.Show(
                    $"Assembly: {assembly.GetName().Name}\n" +
                    $"Version: {assembly.GetName().Version}\n" +
                    $"Strong-Name: {(isStrongNamed ? "Yes" : "No")}\n" +
                    $"Authenticode: {authenticodeStatus}\n\n" +
                    $"Location:\n{location}",
                    "Code Signing Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Could not read signing info:\n{ex.Message}",
                    "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
