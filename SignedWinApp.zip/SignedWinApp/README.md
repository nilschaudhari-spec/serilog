# SignedWinApp – .NET Framework 4.8 Windows Application with Code Signing

A complete sample **Windows Forms** application targeting **.NET Framework 4.8** that demonstrates both:

1. **Strong-name signing** (using a `.snk` key)
2. **Authenticode signing** (using a `.pfx` certificate)

**Sample certificates are included** in the `certificates/` folder.

---

## Project Structure

```
SignedWinApp/
├── SignedWinApp.sln
├── SignedWinApp/
│   ├── SignedWinApp.csproj      ← SignAssembly = true + PostBuildEvent
│   ├── Program.cs
│   ├── MainForm.cs / .Designer.cs
│   ├── App.config
│   └── Properties/AssemblyInfo.cs
├── certificates/
│   ├── SignedWinApp.snk         ← Strong-name key (INCLUDED)
│   ├── SignedWinApp.pfx         ← Authenticode certificate (INCLUDED)
│   ├── SignedWinApp.cer         ← Public certificate
│   ├── SignedWinApp.pem         ← Public certificate (PEM)
│   └── create-sample-cert.ps1   ← Optional: regenerate certificates
└── build-and-sign.ps1           ← Full build + sign script
```

---

## Sample Certificate Details

| File                 | Purpose                              | Password              |
|----------------------|--------------------------------------|-----------------------|
| `SignedWinApp.snk`   | Strong-name key                      | (none)                |
| `SignedWinApp.pfx`   | Authenticode code-signing certificate| `SamplePassword123!`  |
| `SignedWinApp.cer`   | Public certificate (for trust)       | —                     |

- **Subject:** `CN=SignedWinApp Sample, O=Sample Company, C=US`
- **Key:** RSA 2048-bit
- **Usage:** Code Signing
- **Validity:** ~5 years from generation date

> ⚠️ **This is a SELF-SIGNED sample certificate.**  
> Windows will show "Unknown publisher". Do **not** use it in production.

---

## Prerequisites

- Windows 10 / 11
- Visual Studio 2019 or 2022 (or Build Tools) with **.NET Framework 4.8** targeting pack
- Windows 10/11 SDK (for `signtool.exe`) – recommended for Authenticode

---

## Quick Start

### 1. Build & Sign

**Option A – Visual Studio**

1. Open `SignedWinApp.sln`
2. Select **Release** configuration
3. Build → Rebuild Solution  
   The post-build event will automatically call `signtool` using the included `.pfx`.

**Option B – Command line**

```powershell
cd path\to\SignedWinApp
.\build-and-sign.ps1
```

### 2. Run the application

```
SignedWinApp\bin\Release\SignedWinApp.exe
```

On startup you will see a dialog showing strong-name status, Authenticode signer information, and assembly location.

---

## How Signing Works

### Strong-Name Signing

Configured in the `.csproj`:

```xml
<SignAssembly>true</SignAssembly>
<AssemblyOriginatorKeyFile>..\certificates\SignedWinApp.snk</AssemblyOriginatorKeyFile>
```

### Authenticode Signing

Performed after the build by `signtool.exe`:

```powershell
signtool sign /f SignedWinApp.pfx /p "SamplePassword123!" `
              /tr http://timestamp.digicert.com /td sha256 /fd sha256 `
              SignedWinApp.exe
```

---

## Verifying the Signature

```powershell
# Authenticode
signtool verify /pa /v SignedWinApp\bin\Release\SignedWinApp.exe

# Strong name
sn -vf SignedWinApp\bin\Release\SignedWinApp.exe
```

Or right-click the EXE → **Properties** → **Digital Signatures** tab.

---

## Regenerating Certificates (optional)

If you want to create new sample certificates:

```powershell
cd certificates
.\create-sample-cert.ps1   # Run as Administrator
```

---

## Important Security Notes

- The included certificate is **self-signed** for demonstration only.
- Windows will display **"Unknown publisher"** warnings – this is expected.
- For production, purchase a real **Code Signing Certificate** from a trusted CA (DigiCert, Sectigo, GlobalSign, etc.).
- Never commit real private keys to source control.

---

## License

This sample is provided as-is for educational purposes.
