using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace SignedWinApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            LoadApplicationInfo();
        }

        private void LoadApplicationInfo()
        {
            var assembly = Assembly.GetExecutingAssembly();
            var version = assembly.GetName().Version;

            lblTitle.Text = "Signed .NET Framework 4.8 Application";
            lblVersion.Text = $"Version: {version}";
            lblFramework.Text = $".NET Framework: {Environment.Version}";
            lblOS.Text = $"OS: {Environment.OSVersion}";
            lblMachine.Text = $"Machine: {Environment.MachineName}";

            // Show public key token if strong-named
            try
            {
                var publicKeyToken = assembly.GetName().GetPublicKeyToken();
                if (publicKeyToken != null && publicKeyToken.Length > 0)
                {
                    string token = BitConverter.ToString(publicKeyToken).Replace("-", "").ToLowerInvariant();
                    lblStrongName.Text = $"Strong-Name Token: {token}";
                    lblStrongName.ForeColor = Color.DarkGreen;
                }
                else
                {
                    lblStrongName.Text = "Strong-Name: Not signed";
                    lblStrongName.ForeColor = Color.DarkRed;
                }
            }
            catch
            {
                lblStrongName.Text = "Strong-Name: Unable to read";
                lblStrongName.ForeColor = Color.DarkOrange;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "This is a sample Windows Forms application targeting .NET Framework 4.8.\n\n" +
                "It is configured for:\n" +
                "• Strong-name signing (using .snk)\n" +
                "• Authenticode signing (using .pfx)\n\n" +
                "Built with sample self-signed certificate for demonstration purposes only.\n" +
                "Do NOT use the sample certificate in production!",
                "About SignedWinApp",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}
