# =============================================================================
# create-sample-cert.ps1
# Creates sample certificates for Strong-Name + Authenticode signing
# Run this script as Administrator on a Windows machine
# =============================================================================

$ErrorActionPreference = "Stop"
$certDir = $PSScriptRoot

Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Creating Sample Certificates" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# -----------------------------------------------------------------------------
# 1. Create Strong-Name Key (.snk)
# -----------------------------------------------------------------------------
$snkPath = Join-Path $certDir "SignedWinApp.snk"

if (Test-Path $snkPath) {
    Write-Host "[SKIP] Strong-name key already exists: $snkPath" -ForegroundColor Yellow
} else {
    Write-Host "[1/3] Creating Strong-Name key (.snk)..." -ForegroundColor Green

    # Prefer sn.exe from Windows SDK / Visual Studio
    $snExe = $null
    $possibleSnPaths = @(
        "${env:ProgramFiles(x86)}\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.8 Tools\sn.exe",
        "${env:ProgramFiles(x86)}\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.8 Tools\x64\sn.exe",
        "${env:ProgramFiles}\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.8 Tools\sn.exe"
    )

    foreach ($p in $possibleSnPaths) {
        if (Test-Path $p) {
            $snExe = $p
            break
        }
    }

    if ($snExe) {
        & $snExe -k $snkPath
        if ($LASTEXITCODE -ne 0) { throw "sn.exe failed" }
        Write-Host "      Created: $snkPath" -ForegroundColor Green
    } else {
        # Fallback: generate via .NET (works on modern Windows)
        Write-Host "      sn.exe not found – generating via .NET..." -ForegroundColor Yellow
        Add-Type -AssemblyName System.Security
        $csp = New-Object System.Security.Cryptography.CspParameters
        $csp.KeyContainerName = "SignedWinAppTemp"
        $csp.Flags = [System.Security.Cryptography.CspProviderFlags]::UseMachineKeyStore
        $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider(2048, $csp)
        $rsa.PersistKeyInCsp = $false
        $keyPair = $rsa.ExportCspBlob($true)
        [System.IO.File]::WriteAllBytes($snkPath, $keyPair)
        Write-Host "      Created (via RSA): $snkPath" -ForegroundColor Green
    }
}

# -----------------------------------------------------------------------------
# 2. Create Self-Signed Code Signing Certificate (.pfx)
# -----------------------------------------------------------------------------
$pfxPath = Join-Path $certDir "SignedWinApp.pfx"
$cerPath = Join-Path $certDir "SignedWinApp.cer"
$password = "SamplePassword123!"

if (Test-Path $pfxPath) {
    Write-Host "[SKIP] PFX already exists: $pfxPath" -ForegroundColor Yellow
} else {
    Write-Host "[2/3] Creating self-signed Code Signing certificate (.pfx)..." -ForegroundColor Green

    $cert = New-SelfSignedCertificate `
        -Type CodeSigningCert `
        -Subject "CN=SignedWinApp Sample, O=Sample Company, C=US" `
        -KeyAlgorithm RSA `
        -KeyLength 2048 `
        -HashAlgorithm SHA256 `
        -Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" `
        -KeyExportPolicy Exportable `
        -KeyUsage DigitalSignature `
        -NotBefore (Get-Date).AddDays(-1) `
        -NotAfter (Get-Date).AddYears(5) `
        -CertStoreLocation "Cert:\CurrentUser\My"

    $securePassword = ConvertTo-SecureString -String $password -Force -AsPlainText

    # Export to PFX (contains private key)
    Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password $securePassword | Out-Null
    Write-Host "      Created: $pfxPath" -ForegroundColor Green
    Write-Host "      Password: $password" -ForegroundColor Yellow

    # Export public certificate (.cer) for verification / trust
    Export-Certificate -Cert $cert -FilePath $cerPath | Out-Null
    Write-Host "      Created: $cerPath" -ForegroundColor Green

    # Clean up from personal store (optional – keep if you want it installed)
    # Remove-Item -Path "Cert:\CurrentUser\My\$($cert.Thumbprint)" -Force
}

# -----------------------------------------------------------------------------
# 3. Summary
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "[3/3] Certificate files ready:" -ForegroundColor Green
Get-ChildItem $certDir -Include *.snk,*.pfx,*.cer -Recurse | ForEach-Object {
    Write-Host "      $($_.Name)  ($([math]::Round($_.Length/1KB,1)) KB)" -ForegroundColor White
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " IMPORTANT NOTES" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "• This is a SELF-SIGNED sample certificate." -ForegroundColor Yellow
Write-Host "• Windows will show 'Unknown publisher' warnings." -ForegroundColor Yellow
Write-Host "• For production use a certificate from a trusted CA" -ForegroundColor Yellow
Write-Host "  (DigiCert, Sectigo, GlobalSign, etc.)." -ForegroundColor Yellow
Write-Host "• PFX password: SamplePassword123!" -ForegroundColor Yellow
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Open SignedWinApp.sln in Visual Studio" -ForegroundColor White
Write-Host "  2. Build → Rebuild Solution (Release)" -ForegroundColor White
Write-Host "  3. The post-build event will Authenticode-sign the EXE" -ForegroundColor White
Write-Host "  4. Or run build-and-sign.ps1" -ForegroundColor White
Write-Host ""
