# =============================================================================
# build-and-sign.ps1
# Builds the SignedWinApp project and performs Authenticode signing
# Requires: Visual Studio / MSBuild + Windows SDK (signtool)
# =============================================================================

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$project = Join-Path $root "SignedWinApp\SignedWinApp.csproj"
$certDir = Join-Path $root "certificates"
$pfx = Join-Path $certDir "SignedWinApp.pfx"
$snk = Join-Path $certDir "SignedWinApp.snk"
$password = "SamplePassword123!"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host " Build & Sign - SignedWinApp" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# -----------------------------------------------------------------------------
# 0. Ensure certificates exist
# -----------------------------------------------------------------------------
if (-not (Test-Path $snk) -or -not (Test-Path $pfx)) {
    Write-Host "Certificates missing. Creating sample certificates..." -ForegroundColor Yellow
    & (Join-Path $certDir "create-sample-cert.ps1")
}

# -----------------------------------------------------------------------------
# 1. Locate MSBuild
# -----------------------------------------------------------------------------
$msbuild = $null
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"

if (Test-Path $vswhere) {
    $msbuild = & $vswhere -latest -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe | Select-Object -First 1
}

if (-not $msbuild) {
    $fallback = @(
        "${env:ProgramFiles}\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe",
        "${env:ProgramFiles}\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe",
        "${env:ProgramFiles}\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe",
        "${env:ProgramFiles(x86)}\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\MSBuild.exe",
        "${env:ProgramFiles(x86)}\MSBuild\14.0\Bin\MSBuild.exe"
    )
    foreach ($p in $fallback) {
        if (Test-Path $p) { $msbuild = $p; break }
    }
}

if (-not $msbuild) {
    throw "MSBuild not found. Please install Visual Studio or Build Tools."
}

Write-Host "[1/4] Using MSBuild: $msbuild" -ForegroundColor Green

# -----------------------------------------------------------------------------
# 2. Build (Release)
# -----------------------------------------------------------------------------
Write-Host "[2/4] Building Release configuration..." -ForegroundColor Green

& $msbuild $project /t:Rebuild /p:Configuration=Release /p:Platform="Any CPU" /v:minimal
if ($LASTEXITCODE -ne 0) { throw "Build failed" }

$exe = Join-Path $root "SignedWinApp\bin\Release\SignedWinApp.exe"
if (-not (Test-Path $exe)) {
    throw "Output EXE not found: $exe"
}
Write-Host "      Built: $exe" -ForegroundColor Green

# -----------------------------------------------------------------------------
# 3. Locate signtool
# -----------------------------------------------------------------------------
$signtool = $null
$sdkRoots = @(
    "${env:ProgramFiles(x86)}\Windows Kits\10\bin",
    "${env:ProgramFiles}\Windows Kits\10\bin"
)

foreach ($rootSdk in $sdkRoots) {
    if (Test-Path $rootSdk) {
        $candidates = Get-ChildItem -Path $rootSdk -Recurse -Filter "signtool.exe" -ErrorAction SilentlyContinue |
                      Where-Object { $_.FullName -match "\\x64\\" } |
                      Sort-Object FullName -Descending
        if ($candidates) {
            $signtool = $candidates[0].FullName
            break
        }
    }
}

if (-not $signtool) {
    Write-Host "[WARN] signtool.exe not found. Skipping Authenticode signing." -ForegroundColor Yellow
    Write-Host "       Install Windows 10/11 SDK to enable Authenticode signing." -ForegroundColor Yellow
} else {
    Write-Host "[3/4] Using signtool: $signtool" -ForegroundColor Green

    # -------------------------------------------------------------------------
    # 4. Authenticode sign
    # -------------------------------------------------------------------------
    Write-Host "[4/4] Signing with Authenticode..." -ForegroundColor Green

    & $signtool sign `
        /f $pfx `
        /p $password `
        /tr http://timestamp.digicert.com `
        /td sha256 `
        /fd sha256 `
        /d "SignedWinApp - Sample Signed Application" `
        /du "https://example.com" `
        $exe

    if ($LASTEXITCODE -ne 0) {
        Write-Host "      Signing failed (exit $LASTEXITCODE). Continuing..." -ForegroundColor Yellow
    } else {
        Write-Host "      Successfully signed: $exe" -ForegroundColor Green

        # Verify
        Write-Host ""
        Write-Host "Verification:" -ForegroundColor Cyan
        & $signtool verify /pa /v $exe
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " DONE" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Output: $exe" -ForegroundColor White
Write-Host ""
Write-Host "Notes:" -ForegroundColor Yellow
Write-Host "• Strong-name signing is applied via the .snk in the project." -ForegroundColor White
Write-Host "• Authenticode signing uses the sample .pfx (self-signed)." -ForegroundColor White
Write-Host "• Users will see 'Unknown publisher' – expected for self-signed certs." -ForegroundColor White
Write-Host ""
